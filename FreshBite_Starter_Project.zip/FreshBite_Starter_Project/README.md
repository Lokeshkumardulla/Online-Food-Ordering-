# FreshBite
Open index.html in a browser to start.