const foods = [
  {
    id: 1,
    name: 'Margherita Pizza',
    price: 299,
    category: 'Pizza',
    diet: 'veg',
    description: 'Classic cheese pizza with basil and tomato sauce.',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 2,
    name: 'Veg Burger',
    price: 149,
    category: 'Burgers',
    diet: 'veg',
    description: 'Crispy patty with fresh lettuce, tomato and sauce.',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 3,
    name: 'Pasta',
    price: 199,
    category: 'Pasta',
    diet: 'veg',
    description: 'Creamy roasted tomato pasta with herbs.',
    image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 4,
    name: 'Chicken Wrap',
    price: 229,
    category: 'Wraps',
    diet: 'non-veg',
    description: 'Grilled chicken wrap served with crunchy slaw.',
    image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 5,
    name: 'Vegan Bowl',
    price: 189,
    category: 'Healthy',
    diet: 'vegan',
    description: 'Quinoa bowl with roasted veggies and tahini.',
    image: 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=80'
  },
  {
    id: 6,
    name: 'Chicken Biryani',
    price: 269,
    category: 'Biryani',
    diet: 'non-veg',
    description: 'Aromatic rice layered with spiced chicken.',
    image: 'https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?auto=format&fit=crop&w=900&q=80'
  }
];

const restaurants = [
  { name: 'Crispy Corner', rating: 4.8, cuisine: 'Fast Food', delivery: '25 mins', image: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=900&q=80' },
  { name: 'Pasta House', rating: 4.6, cuisine: 'Italian', delivery: '30 mins', image: 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=80' },
  { name: 'Green Grain', rating: 4.9, cuisine: 'Healthy', delivery: '20 mins', image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=900&q=80' }
];

const orders = JSON.parse(localStorage.getItem('orders') || '[]');
let cart = JSON.parse(localStorage.getItem('cart') || '[]');
let selectedDiet = 'all';
let user = JSON.parse(localStorage.getItem('user') || 'null');

function saveCart() {
  localStorage.setItem('cart', JSON.stringify(cart));
}

function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 1800);
}

function updateCartCount() {
  const countEls = document.querySelectorAll('#cartCount');
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  countEls.forEach((el) => {
    el.textContent = count;
  });
}

function addToCart(id) {
  const food = foods.find((item) => item.id === id);
  if (!food) return;
  const existing = cart.find((item) => item.id === id);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ ...food, quantity: 1 });
  }
  saveCart();
  updateCartCount();
  showToast(`${food.name} added to cart`);
}

function changeQuantity(id, delta) {
  cart = cart.map((item) => (item.id === id ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item));
  cart = cart.filter((item) => item.quantity > 0);
  saveCart();
  renderCart();
}

function removeFromCart(id) {
  cart = cart.filter((item) => item.id !== id);
  saveCart();
  renderCart();
}

function getSubtotal() {
  return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

function renderFeaturedItems() {
  const container = document.getElementById('featuredItems');
  if (!container) return;
  container.innerHTML = foods.slice(0, 3).map((food) => `
    <div class="menu-card">
      <img src="${food.image}" alt="${food.name}">
      <div class="card-body">
        <div class="section-head" style="margin: 0 0 0.4rem;">
          <strong>${food.name}</strong>
          <span class="price">₹${food.price}</span>
        </div>
        <p class="meta">${food.description}</p>
        <button class="primary" onclick="addToCart(${food.id})">Add to cart</button>
      </div>
    </div>
  `).join('');
}

function renderMenu() {
  const menuGrid = document.getElementById('menuGrid');
  const filterRow = document.getElementById('dietFilters');
  if (!menuGrid || !filterRow) return;

  const diets = ['all', 'veg', 'non-veg', 'vegan'];
  filterRow.innerHTML = diets.map((diet) => `
    <button class="filter-chip ${selectedDiet === diet ? 'active' : ''}" onclick="setDiet('${diet}')">${diet === 'all' ? 'All' : diet.charAt(0).toUpperCase() + diet.slice(1)}</button>
  `).join('');

  const visibleFoods = selectedDiet === 'all' ? foods : foods.filter((food) => food.diet === selectedDiet);
  menuGrid.innerHTML = visibleFoods.map((food) => `
    <div class="menu-card">
      <img src="${food.image}" alt="${food.name}">
      <div class="card-body">
        <div class="section-head" style="margin: 0 0 0.4rem;">
          <strong>${food.name}</strong>
          <span class="price">₹${food.price}</span>
        </div>
        <p class="meta">${food.description}</p>
        <div class="tags">
          <span class="tag ${food.diet}">${food.diet === 'veg' ? 'Veg' : food.diet === 'non-veg' ? 'Non-Veg' : 'Vegan'}</span>
          <span class="tag">${food.category}</span>
        </div>
        <a class="btn btn-secondary" href="product.html?id=${food.id}" style="display:inline-block; margin-right:0.5rem;">View details</a>
        <button class="primary" onclick="addToCart(${food.id})">Add to cart</button>
      </div>
    </div>
  `).join('');
}

function setDiet(diet) {
  selectedDiet = diet;
  renderMenu();
}

function renderRestaurants() {
  const container = document.getElementById('restaurantList');
  if (!container) return;
  container.innerHTML = restaurants.map((restaurant) => `
    <div class="restaurant-card">
      <img src="${restaurant.image}" alt="${restaurant.name}">
      <div class="card-body">
        <strong>${restaurant.name}</strong>
        <p class="meta">${restaurant.cuisine} • ★ ${restaurant.rating}</p>
        <p class="meta">Delivery in ${restaurant.delivery}</p>
      </div>
    </div>
  `).join('');
}

function renderCart() {
  const container = document.getElementById('cartItems');
  const subtotalEl = document.getElementById('subtotal');
  const totalEl = document.getElementById('total');
  if (!container) return;

  updateCartCount();
  if (!cart.length) {
    container.innerHTML = '<div class="empty-state"><h3>Your cart is empty</h3><p>Pick a few favorites and come back here.</p><a class="btn btn-primary" href="menu.html">Browse menu</a></div>';
    if (subtotalEl) subtotalEl.textContent = '₹0';
    if (totalEl) totalEl.textContent = '₹45';
    return;
  }

  container.innerHTML = cart.map((item) => `
    <div class="cart-item">
      <div>
        <strong>${item.name}</strong>
        <p class="meta">₹${item.price} each</p>
      </div>
      <div class="qty-controls">
        <button class="qty-btn" onclick="changeQuantity(${item.id}, -1)">−</button>
        <span>${item.quantity}</span>
        <button class="qty-btn" onclick="changeQuantity(${item.id}, 1)">+</button>
        <button class="remove-btn" onclick="removeFromCart(${item.id})">Remove</button>
      </div>
    </div>
  `).join('');

  const subtotal = getSubtotal();
  if (subtotalEl) subtotalEl.textContent = `₹${subtotal}`;
  if (totalEl) totalEl.textContent = `₹${subtotal + 45}`;
}

function renderCheckout() {
  renderCart();
  const form = document.getElementById('checkoutForm');
  if (!form) return;
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const summary = {
      name: formData.get('name'),
      phone: formData.get('phone'),
      address: formData.get('address'),
      time: formData.get('time'),
      payment: formData.get('payment'),
      total: getSubtotal() + 45
    };
    orders.push(summary);
    localStorage.setItem('orders', JSON.stringify(orders));
    cart = [];
    localStorage.removeItem('cart');
    renderCart();
    showToast('Order placed successfully!');
    form.reset();
  });
}

function initAuth() {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  if (loginForm) {
    loginForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const email = document.getElementById('loginEmail').value;
      const password = document.getElementById('loginPassword').value;
      if (email && password) {
        user = { name: 'Guest User', email };
        localStorage.setItem('user', JSON.stringify(user));
        showToast('Logged in successfully');
        window.location.href = 'account.html';
      }
    });
  }
  if (registerForm) {
    registerForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const name = document.getElementById('registerName').value;
      const email = document.getElementById('registerEmail').value;
      const password = document.getElementById('registerPassword').value;
      if (name && email && password) {
        user = { name, email };
        localStorage.setItem('user', JSON.stringify(user));
        showToast('Account created successfully');
        window.location.href = 'account.html';
      }
    });
  }
}

function renderAccount() {
  const accountName = document.getElementById('accountName');
  const accountEmail = document.getElementById('accountEmail');
  const historyList = document.getElementById('historyList');
  if (!historyList) return;
  if (user) {
    if (accountName) accountName.textContent = user.name;
    if (accountEmail) accountEmail.textContent = user.email;
  }
  historyList.innerHTML = orders.length ? orders.map((order) => `
    <div class="card" style="padding: 0.8rem; margin: 0;">
      <strong>${order.time}</strong>
      <p class="meta">${order.address}</p>
      <p class="meta">${order.payment} • ₹${order.total}</p>
    </div>
  `).join('') : '<p class="meta">No orders yet.</p>';
}

function renderProductDetail() {
  const container = document.getElementById('productDetail');
  if (!container) return;
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get('id'));
  const food = foods.find((item) => item.id === id);
  if (!food) {
    container.innerHTML = '<div class="empty-state"><h3>Food not found</h3></div>';
    return;
  }
  container.innerHTML = `
    <div class="hero" style="grid-template-columns: 1fr 1fr;">
      <div>
        <img src="${food.image}" alt="${food.name}">
      </div>
      <div>
        <p class="tag ${food.diet}">${food.diet === 'veg' ? 'Veg' : food.diet === 'non-veg' ? 'Non-Veg' : 'Vegan'}</p>
        <h1>${food.name}</h1>
        <p>${food.description}</p>
        <p class="price" style="font-size:1.3rem;">₹${food.price}</p>
        <div class="tags"><span class="tag">${food.category}</span></div>
        <button class="primary" onclick="addToCart(${food.id})">Add to cart</button>
      </div>
    </div>
  `;
}

function initializeApp() {
  updateCartCount();
  renderFeaturedItems();
  renderMenu();
  renderRestaurants();
  renderCart();
  renderCheckout();
  initAuth();
  renderAccount();
  renderProductDetail();
}

window.addEventListener('DOMContentLoaded', initializeApp);
